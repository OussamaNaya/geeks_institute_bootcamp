const http = require('http')
const url = require('url');
const querystring = require('querystring');


const server = http.createServer((req, res) => {


    if (req.method === 'POST' && req.url === '/users') {

        let body = '';

        req.on('data', (chunk) => {
            body = body + chunk.toString();
        })
        req.on('end', ()=>{
            const bodyObj = querystring.parse(body)
            console.log('Received data:', bodyObj);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(bodyObj))
        })
    } else {
        let query = url.parse(req.url, true);
        console.log("query", query)
        res.end('Hello World 1')
    }
})

server.listen(3003, () => {
    console.log('Server is running on port 3003');
})



// GET  query 
//POST  body
